1. The Matlab script 'project1.m' should be present in the 'DataFolder'
2. The script plots the top 5 Principal Components