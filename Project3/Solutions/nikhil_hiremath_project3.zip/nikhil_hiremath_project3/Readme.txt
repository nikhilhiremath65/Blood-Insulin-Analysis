1) All the below mentioned files should be in the current file of the code execution.

mealAmountData1
mealAmountData2
mealAmountData3
mealAmountData4
mealAmountData5

mealData1
mealData2
mealData3
mealData4
mealData5

proj3_test

2) Use 'train.m' to train the model.
	-  returns the accuracy of kmeans and descan
3) Use 'test.m' saves the predicted values of test data in 'Project3_NikhilHiremath.csv'.

