% Read Meal data of 5 subjects
meal_data = readmatrix('mealData1.csv');
meal_data = [meal_data; readmatrix('mealData2.csv')];
meal_data = [meal_data; readmatrix('mealData3.csv')];
meal_data = [meal_data; readmatrix('mealData4.csv')];
meal_data = [meal_data; readmatrix('mealData5.csv')];

meal_data = meal_data(:, 1:30);
% remove rows with NaN values
meal_data = meal_data(sum(isnan(meal_data), 2) == 0, :);

% Read No-meal data of 5 subjects
nomeal_data = readmatrix('Nomeal1.csv');
nomeal_data = [nomeal_data; readmatrix('Nomeal2.csv')];
nomeal_data = [nomeal_data; readmatrix('Nomeal3.csv')];
nomeal_data = [nomeal_data; readmatrix('Nomeal4.csv')];
nomeal_data = [nomeal_data; readmatrix('Nomeal5.csv')];

% remove rows with Nan values
nomeal_data = nomeal_data(sum(isnan(nomeal_data), 2) == 0, :);

X =  [meal_data; nomeal_data];
Y = [repelem(1, size(meal_data, 1))'; repelem(0, size(nomeal_data, 1))'];

% PCA
maxNumFeats = 4;

% Create Feature Matrix
featureMatrix = [];
for row_num = 1:size(X,1)
    trainingData_row = X(row_num,:);
    
    % Fast Fourier Transform of row data
    trainingData_fft = abs(fft(trainingData_row));
    trainingData_fft_values= sort(trainingData_fft,2,'descend');
    trainingData_fft_values= trainingData_fft_values(:, 1:4);

    % Discrete Wavelet Transform of row data
    trainingData_dwt = dwt(trainingData_row,'sym4');
    trainingData_dwt_values = sort(trainingData_dwt,2,'descend');
    trainingData_dwt_values = trainingData_dwt_values(:, 1:4);

    % Moving Standard Deviation of row data
    trainingData_std = movstd(trainingData_row,5);
    trainingData_std_values = sort(trainingData_std,2,'descend');
    trainingData_std_values = trainingData_std_values(:, 1:4);
    
    % Moving Root Mean Square (RMS) of row data
    trainingData_rms = sqrt(movmean(trainingData_row .^ 2, 5));
    trainingData_rms_values = sort(trainingData_rms,2,'descend');
    trainingData_rms_values = trainingData_rms_values(:, 1:4);
    
    vector = [trainingData_fft_values, trainingData_dwt_values, trainingData_std_values, trainingData_rms_values];  
    featureMatrix = [featureMatrix; vector];
end

% Normalize the feature matrix
normFeatMat = normalize(featureMatrix, 'norm', 1);

% Apply PCA on the normalized feature matrix
[coeff, score] = pca(normFeatMat(1:size(meal_data, 1), :));

numFeatures = 5;
% Extract top 5 features
topEigens = coeff(:, 1:numFeatures);
% New Feature Matrix
newFeatMatrix = featureMatrix*topEigens;


% Train the machine on updated feature matrix

%trained_model = fitcensemble(newFeatMatrix, Y);
%trained_model = fitcnb(newFeatMatrix, Y);
%trained_model = fitcknn(newFeatMatrix, Y,'NumNeighbors',10,'Standardize',1);
trained_model = fitcdiscr(newFeatMatrix, Y, 'DiscrimType','quadratic');
%trained_model = fitctree(newFeatMatrix, Y, 'MaxNumSplits', 7);


% Perform k-fold Cross Validation
cvm = crossval(trained_model, 'KFold', 5);
y_predict = kfoldPredict(cvm);

% Save variables
save trainedModel.mat trained_model;

% Compute metrics using k-fold cross validation
confusionMatrix = confusionmat(Y, y_predict);

TP = confusionMatrix(1,1);
FP = confusionMatrix(1,2);
FN = confusionMatrix(2,1);
TN = confusionMatrix(2,2);
accuracy = (TP+TN)/(TP+FP+FN+TN)*100;
precision = TP/(TP+FP);
recall = TP/(TP+FN);
F1 = (2 * precision * recall) / (precision + recall);

fprintf("accuracy=%.02f%%, p=%f, r=%f, F1=%f\n", accuracy, precision, recall, F1);



