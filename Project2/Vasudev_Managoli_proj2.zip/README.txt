1. train.m file should be present in the folder MealNoMealData
2. train.m outputs trainedModel.mat file in the same folder as train.m
3. test.m uses saved trainedModel.mat to predict input data