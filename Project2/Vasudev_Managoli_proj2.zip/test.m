load trainedModel;
filename = input('Enter test CSV filename: ', 's');
% No-meal file: MealNoMealData/Nomeal1.csv
% meal file: MealNoMealData/mealData1.csv
test_data = readmatrix(filename);
X = test_data(:, 1:30);
X = fillmissing(X, 'linear', 1);

% Create Feature Matrix
featureMatrix = [];
for row_num = 1:size(X,1)
    trainingData_row = X(row_num, :);
    
    % Fast Fourier Transform of row data
    trainingData_fft = abs(fft(trainingData_row));
    trainingData_fft_values= sort(trainingData_fft,2,'descend');
    trainingData_fft_values= trainingData_fft_values(:, 1:4);

    % Discrete Wavelet Transform of row data
    trainingData_dwt = dwt(trainingData_row,'sym4');
    trainingData_dwt_values = sort(trainingData_dwt,2,'descend');
    trainingData_dwt_values = trainingData_dwt_values(:, 1:4);

    % Moving Standard Deviation of row data
    trainingData_std = movstd(trainingData_row,5);
    trainingData_std_values = sort(trainingData_std,2,'descend');
    trainingData_std_values = trainingData_std_values(:, 1:4);
    
    % Moving Root Mean Square (RMS) of row data
    trainingData_rms = sqrt(movmean(trainingData_row .^ 2, 5));
    trainingData_rms_values = sort(trainingData_rms,2,'descend');
    trainingData_rms_values = trainingData_rms_values(:, 1:4);
    
    vector = [trainingData_fft_values, trainingData_dwt_values, trainingData_std_values, trainingData_rms_values];  
    featureMatrix = [featureMatrix; vector];
end

newFeatMatrix = featureMatrix*topEigens;

y = predict(trained_model, newFeatMatrix);
disp(y);
