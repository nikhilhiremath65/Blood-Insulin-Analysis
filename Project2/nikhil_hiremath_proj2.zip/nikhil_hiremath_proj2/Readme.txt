1) All the files should be in the current file of the code execution.
2) Use 'train.m' to train the model.
	-  returns a trained ML model in .mat format
3) Use 'test.m' to train the model.


